#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${PYTHON_BIN:-${SCRIPT_DIR}/../../.venv/bin/python}"
QUICK_FLAG=""

if [[ ! -x "${PYTHON_BIN}" ]]; then
  echo "Python executable not found or not executable: ${PYTHON_BIN}" >&2
  echo "Set PYTHON_BIN to a valid interpreter, for example:" >&2
  echo "  PYTHON_BIN=.venv/bin/python bash examples/colleague_examples/run_all.sh --quick" >&2
  exit 1
fi

run() {
  local script_path="$1"
  echo "Running ${script_path}"
  "${PYTHON_BIN}" "${SCRIPT_DIR}/${script_path}"
}

# Laminar simulations + parameter sweep + plots
run "laminar/fixed_angle_sweep.py"
run "laminar/monochromator_sweep.py"
run "laminar/parameter_sweep.py"
run "laminar/plot_results.py"

# Blazed simulations + parameter sweep + plots
run "blazed/fixed_angle_sweep.py"
run "blazed/monochromator_sweep.py"
run "blazed/parameter_sweep.py"
run "blazed/plot_results.py"

echo "All colleague examples finished."

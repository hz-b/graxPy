"""Run a blazed monochromator sweep with CXRO files and xrt-Henke materials."""

from __future__ import annotations

from pathlib import Path
import os
import sys

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "src"))

example_dir = Path(__file__).resolve().parent
results_dir = example_dir / "results"
plots_dir = example_dir / "plots"
mpl_cache_dir = results_dir / ".mplcache"
results_dir.mkdir(parents=True, exist_ok=True)
plots_dir.mkdir(parents=True, exist_ok=True)
mpl_cache_dir.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("MPLCONFIGDIR", str(mpl_cache_dir))

import numpy as np
import pandas as pd
from xrt.backends.raycing import materials as xrt_materials

import reticolopy as rp

optical_constants_dir = example_dir / "optical_constants" / "cxro"
energies_ev = np.arange(50.0, 650.0, 10.0)

silicon_cxro = pd.read_csv(optical_constants_dir / "n_Si_cxro.txt", skiprows=1, sep=r"\s*,\s*|\s+", engine="python")
silicon_cxro.attrs["name"] = "Si CXRO"
platinum_cxro = pd.read_csv(optical_constants_dir / "n_Pt_cxro.txt", skiprows=1, sep=r"\s*,\s*|\s+", engine="python")
platinum_cxro.attrs["name"] = "Pt CXRO"

cxro_grating = rp.BlazedGrating(
    period_lpermm=600,
    blaze_angle_deg=0.9,
    substrate_material=silicon_cxro,
    layer_material=platinum_cxro,
    layer_thickness_nm=28.77,
    z_resolution_nm=0.1,
    x_resolution_nm=1.0,
)
xrt_grating = rp.BlazedGrating(
    period_lpermm=600,
    blaze_angle_deg=0.9,
    substrate_material=xrt_materials.Material("Si", rho=2.33, table="Henke", name="Si xrt-Henke"),
    layer_material=xrt_materials.Material("Pt", rho=20.13, table="Henke", name="Pt xrt-Henke"),
    layer_thickness_nm=28.77,
    z_resolution_nm=0.1,
    x_resolution_nm=1.0,
)
grazing_angles_deg = rp.monochromator_grazing_angles_deg(
    energies_ev,
    period_lpermm=cxro_grating.period_lpermm,
    diffraction_order=1,
    cff=2.25,
)

for source, grating in {"cxro": cxro_grating, "xrt_henke": xrt_grating}.items():
    grating.plot_profile(plots_dir / f"monochromator_{source}_grating_profile.png")
    cases = [
        {
            "label": f"blazed monochromator {source}: E={energy:.1f} eV",
            "grating": grating,
            "energy_ev": float(energy),
            "grazing_angle_deg": float(grazing_angle),
        }
        for energy, grazing_angle in zip(energies_ev, grazing_angles_deg)
    ]
    runner = rp.BatchSimulationRunner(
        default_diffraction_order=1,
        default_fourier_orders=5,
        show_progress=True,
        live_plot=False,
        on_error="fail_fast",
        checkpoint_dir=str(results_dir / "checkpoints" / f"monochromator_{source}"),
        resume=False,
    )
    result = runner.run_cases(cases)
    rp.write_order_subset_csv(
        result,
        results_dir / f"monochromator_{source}_orders_1_3.csv",
        diffraction_orders=[1, 2, 3],
    )

print(f"Blazed monochromator CSVs saved to: {results_dir}")
print(f"Blazed monochromator profile plots saved to: {plots_dir}")

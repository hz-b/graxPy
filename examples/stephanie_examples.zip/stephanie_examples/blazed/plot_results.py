"""Plot saved blazed CSV outputs without rerunning simulations."""

from __future__ import annotations

from pathlib import Path
import os
import sys

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "src"))

example_dir = Path(__file__).resolve().parent
results_dir = example_dir / "results"
plots_dir = example_dir / "plots"
mpl_cache_dir = results_dir / ".mplcache"
results_dir.mkdir(parents=True, exist_ok=True)
plots_dir.mkdir(parents=True, exist_ok=True)
mpl_cache_dir.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("MPLCONFIGDIR", str(mpl_cache_dir))

import matplotlib.pyplot as plt
import pandas as pd

plot_specs = [
    (
        {
            "cxro": results_dir / "fixed_angle_cxro_orders_1_3.csv",
            "xrt_henke": results_dir / "fixed_angle_xrt_henke_orders_1_3.csv",
        },
        plots_dir / "fixed_angle_cxro_vs_xrt_henke.png",
        "Blazed Fixed-Angle Sweep: CXRO vs xrt-Henke",
        [1, 2, 3],
    ),
    (
        {
            "cxro": results_dir / "monochromator_cxro_orders_1_3.csv",
            "xrt_henke": results_dir / "monochromator_xrt_henke_orders_1_3.csv",
        },
        plots_dir / "monochromator_cxro_vs_xrt_henke.png",
        "Blazed Monochromator Sweep: CXRO vs xrt-Henke",
        [1, 2, 3],
    ),
]
labels = {"cxro": "CXRO file", "xrt_henke": "xrt-Henke Material"}
markers = {"cxro": "o", "xrt_henke": "^"}

for csv_paths, plot_path, title, diffraction_orders in plot_specs:
    figure, axis = plt.subplots(figsize=(10, 6))
    for source, csv_path in csv_paths.items():
        data = pd.read_csv(csv_path)
        for order in diffraction_orders:
            axis.plot(
                data["energy_ev"],
                data[f"efficiency_order_{order}"],
                marker=markers[source],
                linewidth=1.0,
                markersize=3.0,
                label=f"{labels[source]} order {order}",
            )
    axis.set_xlabel("Photon Energy (eV)")
    axis.set_ylabel("Diffraction Efficiency")
    axis.set_title(title)
    axis.grid(True, alpha=0.3)
    axis.legend(loc="best")
    figure.tight_layout()
    figure.savefig(plot_path, dpi=150, bbox_inches="tight")
    plt.close(figure)

print(f"Blazed plots saved to: {plots_dir}")

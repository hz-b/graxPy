"""Run a laminar fixed-angle sweep with CXRO files and xrt-Henke materials."""

from __future__ import annotations

from pathlib import Path
import os
import sys

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "src"))

example_dir = Path(__file__).resolve().parent
results_dir = example_dir / "results"
plots_dir = example_dir / "plots"
mpl_cache_dir = results_dir / ".mplcache"
results_dir.mkdir(parents=True, exist_ok=True)
plots_dir.mkdir(parents=True, exist_ok=True)
mpl_cache_dir.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("MPLCONFIGDIR", str(mpl_cache_dir))

import numpy as np
import pandas as pd
from xrt.backends.raycing import materials as xrt_materials

import reticolopy as rp

optical_constants_dir = example_dir / "optical_constants" / "cxro"
energies_ev = np.arange(50.0, 650.1, 10.0)
grazing_angles_deg = np.full_like(energies_ev, 4.0, dtype=float)

silicon_cxro = pd.read_csv(optical_constants_dir / "n_Si_cxro.txt", skiprows=1, sep=r"\s*,\s*|\s+", engine="python")
silicon_cxro.attrs["name"] = "Si CXRO"
platinum_cxro = pd.read_csv(optical_constants_dir / "n_Pt_cxro.txt", skiprows=1, sep=r"\s*,\s*|\s+", engine="python")
platinum_cxro.attrs["name"] = "Pt CXRO"
carbon_cxro = pd.read_csv(optical_constants_dir / "n_C_cxro.txt", skiprows=1, sep=r"\s*,\s*|\s+", engine="python")
carbon_cxro.attrs["name"] = "C CXRO"

cxro_grating = rp.LaminarGrating(
    period_lpermm=400,
    width_to_period_ratio=0.67,
    depth_nm=14.9,
    left_wall_angle_deg=15.0,
    right_wall_angle_deg=15.0,
    substrate_material=silicon_cxro,
    layer_material=platinum_cxro,
    layer_thickness_nm=28.77,
    top_cap_material=carbon_cxro,
    top_cap_thickness_nm=0.7,
    z_resolution_nm=0.1,
    x_resolution_nm=1.0,
)
xrt_grating = rp.LaminarGrating(
    period_lpermm=400,
    width_to_period_ratio=0.67,
    depth_nm=14.9,
    left_wall_angle_deg=15.0,
    right_wall_angle_deg=15.0,
    substrate_material=xrt_materials.Material("Si", rho=2.33, table="Henke", name="Si xrt-Henke"),
    layer_material=xrt_materials.Material("Pt", rho=20.13, table="Henke", name="Pt xrt-Henke"),
    layer_thickness_nm=28.77,
    top_cap_material=xrt_materials.Material("C", rho=2.2, table="Henke", name="C xrt-Henke"),
    top_cap_thickness_nm=0.7,
    z_resolution_nm=0.1,
    x_resolution_nm=1.0,
)

for source, grating in {"cxro": cxro_grating, "xrt_henke": xrt_grating}.items():
    grating.plot_profile(plots_dir / f"fixed_angle_{source}_grating_profile.png")
    cases = [
        {
            "label": f"laminar fixed-angle {source}: E={energy:.1f} eV",
            "grating": grating,
            "energy_ev": float(energy),
            "grazing_angle_deg": float(grazing_angle),
        }
        for energy, grazing_angle in zip(energies_ev, grazing_angles_deg)
    ]
    runner = rp.BatchSimulationRunner(
        default_diffraction_order=1,
        default_fourier_orders=5,
        show_progress=True,
        live_plot=False,
        on_error="fail_fast",
        checkpoint_dir=str(results_dir / "checkpoints" / f"fixed_angle_{source}"),
        resume=False,
    )
    result = runner.run_cases(cases)
    rp.write_order_subset_csv(
        result,
        results_dir / f"fixed_angle_{source}_orders_1.csv",
        diffraction_orders=[1],
    )

print(f"Laminar fixed-angle CSVs saved to: {results_dir}")
print(f"Laminar fixed-angle profile plots saved to: {plots_dir}")

"""Run full laminar parameter sweeps with xrt-Henke materials."""

from __future__ import annotations

from pathlib import Path
import os
import sys

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "src"))

example_dir = Path(__file__).resolve().parent
results_dir = example_dir / "results"
plots_dir = example_dir / "plots"
mpl_cache_dir = results_dir / ".mplcache"
results_dir.mkdir(parents=True, exist_ok=True)
plots_dir.mkdir(parents=True, exist_ok=True)
mpl_cache_dir.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("MPLCONFIGDIR", str(mpl_cache_dir))

import numpy as np
from xrt.backends.raycing import materials as xrt_materials

import reticolopy as rp

energies_ev = [100.0, 1000.0]
sweeps_dir = results_dir / "parameter_sweep_sweeps"
parameters = rp.ParameterRange(
    x_resolution=np.array([0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1, 5, 10], dtype=float),
    z_resolution=np.array([0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1, 5, 10], dtype=float),
    fourier_orders=np.arange(5, 26, 5, dtype=int),
)
xrt_grating = rp.LaminarGrating(
    period_lpermm=400,
    width_to_period_ratio=0.67,
    depth_nm=14.9,
    left_wall_angle_deg=15.0,
    right_wall_angle_deg=15.0,
    substrate_material=xrt_materials.Material("Si", rho=2.33, table="Henke", name="Si xrt-Henke"),
    layer_material=xrt_materials.Material("Pt", rho=20.13, table="Henke", name="Pt xrt-Henke"),
    layer_thickness_nm=28.77,
    top_cap_material=xrt_materials.Material("C", rho=2.2, table="Henke", name="C xrt-Henke"),
    top_cap_thickness_nm=0.7,
    z_resolution_nm=0.1,
    x_resolution_nm=1.0,
)

xrt_grating.plot_profile(plots_dir / "parameter_sweep_xrt_henke_grating_profile.png")
sweep_results = rp.run_full_parameter_sweep(
    grating=xrt_grating,
    energies=energies_ev,
    parameters=parameters,
    diffraction_order=1,
    max_retries=0,
    output_dir=str(sweeps_dir),
)
plot_path = plots_dir / "parameter_sweep_grid.png"
rp.plot_multi_parameter_grid(sweep_results, output_filename=str(plot_path))

print(f"Laminar parameter sweep CSVs saved to: {sweeps_dir}")
print(f"Laminar parameter sweep grid plot saved to: {plot_path}")
print(f"Laminar parameter sweep profile plots saved to: {plots_dir}")
